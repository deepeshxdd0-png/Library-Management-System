// Dashboard functionality
document.addEventListener('DOMContentLoaded', async () => {
    // Load dashboard stats
    await loadDashboardStats();
    await loadRecentBooks();
});

async function loadDashboardStats() {
    try {
        // For now, we'll use placeholder data
        // In production, these would come from API endpoints
        
        // Show health status
        const health = await API.Health.checkHealth();
        console.log('System health:', health);
        
        // Update stats (using sample data for now)
        document.getElementById('total-books').textContent = '30';
        document.getElementById('total-members').textContent = '-';
        document.getElementById('active-borrows').textContent = '-';
        document.getElementById('outstanding-fines').textContent = '$0.00';
        
    } catch (error) {
        console.error('Error loading dashboard stats:', error);
    }
}

async function loadRecentBooks() {
    const booksContainer = document.getElementById('recent-books');
    
    // For demonstration, we'll show a few sample books
    // In production, this would fetch from the API
    
    const sampleBooks = [
        { title: 'Alice\'s Adventures in Wonderland', author: 'Lewis Carroll', isbn: 'PG000011' },
        { title: 'Pride and Prejudice', author: 'Jane Austen', isbn: 'PG001342' },
        { title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', isbn: '9780141182636' },
    ];
    
    booksContainer.innerHTML = sampleBooks.map(book => `
        <div class="book-card">
            <h4>${escapeHtml(book.title)}</h4>
            <div class="author">by ${escapeHtml(book.author)}</div>
            <div class="isbn">ISBN: ${escapeHtml(book.isbn)}</div>
            <a href="books.html?isbn=${book.isbn}" class="btn btn-primary" style="margin-top: 1rem; display: inline-block;">View Details</a>
        </div>
    `).join('');
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}



