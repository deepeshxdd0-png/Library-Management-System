// Return functionality
function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alert-container');
    alertContainer.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    setTimeout(() => {
        alertContainer.innerHTML = '';
    }, 5000);
}

async function returnBook(event) {
    event.preventDefault();
    
    const returnData = {
        log_id: parseInt(document.getElementById('log-id').value)
    };
    
    const resultContainer = document.getElementById('return-result');
    resultContainer.innerHTML = '<div class="loading"><div class="spinner"></div><p>Processing return...</p></div>';
    
    try {
        const result = await API.Borrow.returnBook(returnData);
        
        if (result.fine_charged) {
            resultContainer.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <h3>Book Returned - Fine Charged</h3>
                    </div>
                    <div class="alert alert-warning">
                        <strong>⚠️ Late Return:</strong> A fine has been charged for this overdue return.
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                        <div>
                            <h4>Return Details</h4>
                            <table>
                                <tr>
                                    <td><strong>Transaction ID:</strong></td>
                                    <td>${result.log_id}</td>
                                </tr>
                                <tr>
                                    <td><strong>Return Date:</strong></td>
                                    <td>${formatDate(result.return_date)}</td>
                                </tr>
                                <tr>
                                    <td><strong>Status:</strong></td>
                                    <td>${result.status}</td>
                                </tr>
                            </table>
                        </div>
                        <div>
                            <h4>Fine Information</h4>
                            <table>
                                <tr>
                                    <td><strong>Fine ID:</strong></td>
                                    <td>${result.fine_id}</td>
                                </tr>
                                <tr>
                                    <td><strong>Status:</strong></td>
                                    <td class="alert alert-danger">Charged</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            `;
            showAlert('Book returned with fine charged!', 'warning');
        } else {
            resultContainer.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <h3>Book Returned Successfully!</h3>
                    </div>
                    <div class="alert alert-success">
                        ✅ Book returned on time with no fines.
                    </div>
                    <div>
                        <h4>Return Details</h4>
                        <table>
                            <tr>
                                <td><strong>Transaction ID:</strong></td>
                                <td>${result.log_id}</td>
                            </tr>
                            <tr>
                                <td><strong>Return Date:</strong></td>
                                <td>${formatDate(result.return_date)}</td>
                            </tr>
                            <tr>
                                <td><strong>Status:</strong></td>
                                <td>${result.status}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            `;
            showAlert('Book returned successfully!', 'success');
        }
        
        // Reset form
        document.getElementById('return-form').reset();
        
    } catch (error) {
        resultContainer.innerHTML = `
            <div class="alert alert-danger">
                <strong>Return Failed:</strong> ${error.message}
            </div>
        `;
        showAlert(error.message, 'danger');
    }
}

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}



