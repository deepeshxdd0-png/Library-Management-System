// Borrow functionality
document.addEventListener('DOMContentLoaded', async () => {
    await hydrateSelectors();
});

function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alert-container');
    alertContainer.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    setTimeout(() => {
        alertContainer.innerHTML = '';
    }, 5000);
}

async function hydrateSelectors() {
    const memberSelect = document.getElementById('member-select');
    const bookSelect = document.getElementById('book-select');
    memberSelect.innerHTML = '<option value="">Loading members...</option>';
    bookSelect.innerHTML = '<option value="">Loading books...</option>';
    try {
        const [members, books] = await Promise.all([
            API.Member.getMembers(),
            getBooksList(),
        ]);
        // Members
        memberSelect.innerHTML = '<option value="">-- Select Member --</option>' +
            members.map(m => `<option value="${m.member_id}">${escapeHtml(m.first_name)} ${escapeHtml(m.last_name)} (ID: ${m.member_id})</option>`).join('');
        // Books
        bookSelect.innerHTML = '<option value="">-- Select Book --</option>' +
            books.map(b => `<option value="${b.isbn}">${escapeHtml(b.title)} [${escapeHtml(b.isbn)}]</option>`).join('');

        // Sync hidden inputs on change
        memberSelect.addEventListener('change', () => {
            document.getElementById('member-id').value = memberSelect.value ? parseInt(memberSelect.value) : '';
        });
        bookSelect.addEventListener('change', () => {
            document.getElementById('isbn').value = bookSelect.value || '';
        });
    } catch (e) {
        showAlert(`Failed to load members/books: ${e.message}`, 'danger');
    }
}

async function borrowBook(event) {
    event.preventDefault();
    
    const borrowData = {
        member_id: parseInt(document.getElementById('member-id').value),
        isbn: document.getElementById('isbn').value,
        borrowing_period_days: parseInt(document.getElementById('borrowing-period').value)
    };
    
    const resultContainer = document.getElementById('borrow-result');
    resultContainer.innerHTML = '<div class="loading"><div class="spinner"></div><p>Processing borrow request...</p></div>';
    
    try {
        const result = await API.Borrow.borrowBook(borrowData);
        
        resultContainer.innerHTML = `
            <div class="card">
                <div class="card-header">
                    <h3>Book Borrowed Successfully!</h3>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div>
                        <h4>Transaction Details</h4>
                        <table>
                            <tr>
                                <td><strong>Transaction ID:</strong></td>
                                <td>${result.log_id}</td>
                            </tr>
                            <tr>
                                <td><strong>Member ID:</strong></td>
                                <td>${result.member_id}</td>
                            </tr>
                            <tr>
                                <td><strong>ISBN:</strong></td>
                                <td>${result.isbn}</td>
                            </tr>
                        </table>
                    </div>
                    <div>
                        <h4>Due Date Information</h4>
                        <table>
                            <tr>
                                <td><strong>Borrow Date:</strong></td>
                                <td>${formatDate(result.borrow_date)}</td>
                            </tr>
                            <tr>
                                <td><strong>Due Date:</strong></td>
                                <td><strong style="color: var(--warning-color);">${formatDate(result.due_date)}</strong></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        `;
        
        showAlert('Book borrowed successfully!', 'success');
        
        // Reset form
        document.getElementById('borrow-form').reset();
        
    } catch (error) {
        resultContainer.innerHTML = `
            <div class="alert alert-danger">
                <strong>Borrowing Failed:</strong> ${error.message}
            </div>
        `;
        showAlert(error.message, 'danger');
    }
}

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function escapeHtml(text) {
    if (text === null || text === undefined) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function getBooksList() {
    if (window.API && window.API.Book && typeof window.API.Book.listBooks === 'function') {
        return window.API.Book.listBooks();
    }
    const resp = await fetch('/api/books');
    if (!resp.ok) throw new Error('Failed to load books');
    return resp.json();
}



