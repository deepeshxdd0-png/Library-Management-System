// Fines functionality
function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alert-container');
    alertContainer.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    setTimeout(() => {
        alertContainer.innerHTML = '';
    }, 5000);
}

async function searchFines(event) {
    event.preventDefault();
    
    const memberId = parseInt(document.getElementById('member-id').value);
    const resultsContainer = document.getElementById('fines-results');
    resultsContainer.innerHTML = '<div class="loading"><div class="spinner"></div><p>Loading fines...</p></div>';
    
    try {
        const fines = await API.Fines.getFines(memberId);
        
        if (fines.length === 0) {
            resultsContainer.innerHTML = `
                <div class="card">
                    <div class="empty-state">
                        <div class="empty-state-icon">✅</div>
                        <h3>No Outstanding Fines</h3>
                        <p>This member has no unpaid fines.</p>
                    </div>
                </div>
            `;
        } else {
            const totalFines = fines.reduce((sum, fine) => sum + parseFloat(fine.amount), 0);
            
            resultsContainer.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <h3>Outstanding Fines for Member ${memberId}</h3>
                        <div class="alert alert-danger" style="margin-top: 1rem;">
                            <strong>Total Outstanding: ${formatCurrency(totalFines)}</strong>
                        </div>
                    </div>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Fine ID</th>
                                    <th>Book</th>
                                    <th>ISBN</th>
                                    <th>Amount</th>
                                    <th>Days Overdue</th>
                                    <th>Due Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${fines.map(fine => `
                                    <tr>
                                        <td>${fine.fine_id}</td>
                                        <td>${escapeHtml(fine.title)}</td>
                                        <td>${escapeHtml(fine.isbn)}</td>
                                        <td><strong>${formatCurrency(fine.amount)}</strong></td>
                                        <td>${fine.days_overdue} days</td>
                                        <td>${formatDate(fine.due_date)}</td>
                                        <td>
                                            <button class="btn btn-success" onclick="payFine(${fine.fine_id})">
                                                Pay Fine
                                            </button>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        }
        
    } catch (error) {
        resultsContainer.innerHTML = `
            <div class="alert alert-danger">
                <strong>Error:</strong> ${error.message}
            </div>
        `;
        showAlert(error.message, 'danger');
    }
}

async function payFine(fineId) {
    if (!confirm(`Are you sure you want to pay Fine ID ${fineId}?`)) {
        return;
    }
    
    try {
        const result = await API.Fines.payFine({ fine_id: fineId });
        showAlert(result.message || 'Fine paid successfully!', 'success');
        
        // Refresh the list
        const memberId = document.getElementById('member-id').value;
        if (memberId) {
            setTimeout(() => {
                document.getElementById('member-id').dispatchEvent(new Event('change'));
                searchFines({ preventDefault: () => {} });
            }, 1000);
        }
        
    } catch (error) {
        showAlert(error.message, 'danger');
    }
}

function formatCurrency(amount) {
    return `$${parseFloat(amount).toFixed(2)}`;
}

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function escapeHtml(text) {
    if (text === null || text === undefined) return 'N/A';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}



