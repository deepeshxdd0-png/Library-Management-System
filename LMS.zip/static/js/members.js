// Members registration functionality
function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alert-container');
    alertContainer.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    setTimeout(() => {
        alertContainer.innerHTML = '';
    }, 5000);
}

async function registerMember(event) {
    event.preventDefault();
    
    const memberData = {
        first_name: document.getElementById('first-name').value,
        last_name: document.getElementById('last-name').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        address: document.getElementById('address').value,
        membership_type: document.getElementById('membership-type').value,
        borrowing_limit: parseInt(document.getElementById('borrowing-limit').value)
    };
    
    const resultContainer = document.getElementById('registration-result');
    resultContainer.innerHTML = '<div class="loading"><div class="spinner"></div><p>Registering member...</p></div>';
    
    try {
        const result = await API.Member.registerMember(memberData);
        
        resultContainer.innerHTML = `
            <div class="card">
                <div class="card-header">
                    <h3>Member Registered Successfully!</h3>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div>
                        <h4>Member Information</h4>
                        <table>
                            <tr>
                                <td><strong>Member ID:</strong></td>
                                <td>${result.member_id}</td>
                            </tr>
                            <tr>
                                <td><strong>Name:</strong></td>
                                <td>${result.first_name} ${result.last_name}</td>
                            </tr>
                            <tr>
                                <td><strong>Email:</strong></td>
                                <td>${result.email}</td>
                            </tr>
                            <tr>
                                <td><strong>Phone:</strong></td>
                                <td>${result.phone || 'N/A'}</td>
                            </tr>
                        </table>
                    </div>
                    <div>
                        <h4>Membership Details</h4>
                        <table>
                            <tr>
                                <td><strong>Membership Type:</strong></td>
                                <td>${result.membership_type}</td>
                            </tr>
                            <tr>
                                <td><strong>Status:</strong></td>
                                <td>${result.status}</td>
                            </tr>
                            <tr>
                                <td><strong>Borrowing Limit:</strong></td>
                                <td>${result.borrowing_limit}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        `;
        
        showAlert('Member registered successfully!', 'success');
        
        // Reset form
        document.getElementById('member-form').reset();
        
    } catch (error) {
        resultContainer.innerHTML = `
            <div class="alert alert-danger">
                <strong>Registration Failed:</strong> ${error.message}
            </div>
        `;
        showAlert(error.message, 'danger');
    }
}



