// Analytics functionality
document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('btn-generate-report');
    const output = document.getElementById('report-output');
    if (btn) {
        btn.addEventListener('click', async () => {
            btn.disabled = true;
            const originalText = btn.textContent;
            btn.textContent = 'Generating...';
            output.style.display = 'block';
            output.textContent = 'Generating report...';
            try {
                const res = await fetch('/api/generate-report?format=json');
                if (!res.ok) throw new Error('Failed to generate report');
                const data = await res.json();
                renderPrettyReport(output, data);
            } catch (e) {
                output.textContent = `Error: ${e.message}`;
            } finally {
                btn.disabled = false;
                btn.textContent = originalText;
            }
        });
    }
});

function renderPrettyReport(container, data) {
    const sections = data.sections || {};
    const esc = (t) => {
        if (t === null || t === undefined) return '';
        const d = document.createElement('div');
        d.textContent = t;
        return d.innerHTML;
    };

    const authorsRows = (sections.top_authors || []).map((a, i) => `
        <tr>
            <td>${i + 1}</td>
            <td>${esc(a.first_name)} ${esc(a.last_name)}</td>
            <td>${esc(a.nationality || '—')}</td>
            <td>${a.book_count}</td>
        </tr>
    `).join('');

    const monthRows = (sections.monthly_trends || []).map(m => `
        <tr>
            <td>${esc(String(m.month).slice(0, 10))}</td>
            <td>${m.borrow_count}</td>
        </tr>
    `).join('');

    const genreRows = (sections.genre_trends || []).map(g => `
        <tr>
            <td>${esc(g.genre || 'Unspecified')}</td>
            <td>${g.borrow_count}</td>
        </tr>
    `).join('');

    const bookRows = (sections.popular_books || []).map((b, i) => `
        <tr>
            <td>${i + 1}</td>
            <td>${esc(b.title)}</td>
            <td>${esc(b.isbn)}</td>
            <td>${b.borrow_count}</td>
            <td>${b.available_copies}/${b.total_copies}</td>
        </tr>
    `).join('');

    const memberRows = (sections.active_members || []).map((m, i) => `
        <tr>
            <td>${i + 1}</td>
            <td>${esc(m.first_name)} ${esc(m.last_name)}</td>
            <td>${esc(m.email)}</td>
            <td>${esc(m.membership_type)}</td>
            <td>${m.recent_borrows}</td>
        </tr>
    `).join('');

    const overdueRows = (sections.overdue_books || []).map(o => `
        <tr>
            <td>${esc(o.title)}</td>
            <td>${esc(o.isbn)}</td>
            <td>${esc(o.member_name)}</td>
            <td>${esc(String(o.due_date).slice(0, 10))}</td>
            <td>${o.days_overdue}</td>
            <td>$${Number(o.estimated_fine || 0).toFixed(2)}</td>
            <td>${esc(o.fine_status)}</td>
        </tr>
    `).join('');

    container.style.whiteSpace = 'normal';
    container.innerHTML = `
        <div class="card" style="background: transparent; box-shadow: none; padding: 0;">
            <div class="card-header"><h3>Comprehensive Analytics Report</h3></div>
            <div class="stats-grid" style="margin-bottom: 1rem;">
                <div class="stat-card"><div class="stat-icon">👨‍🏫</div><div class="stat-content"><h3>${(sections.top_authors||[]).length}</h3><p>Prolific Authors</p></div></div>
                <div class="stat-card"><div class="stat-icon">📚</div><div class="stat-content"><h3>${(sections.popular_books||[]).length}</h3><p>Popular Books</p></div></div>
                <div class="stat-card"><div class="stat-icon">📈</div><div class="stat-content"><h3>${(sections.monthly_trends||[]).length}</h3><p>Monthly Data Points</p></div></div>
                <div class="stat-card"><div class="stat-icon">⏰</div><div class="stat-content"><h3>${(sections.overdue_books||[]).length}</h3><p>Overdue</p></div></div>
            </div>

            <h4 style="margin-top: 1rem;">1. Top 5 Most Prolific Authors</h4>
            <div style="overflow:auto;">
                <table>
                    <thead><tr><th>#</th><th>Name</th><th>Nationality</th><th>Books</th></tr></thead>
                    <tbody>${authorsRows || '<tr><td colspan="4">No data</td></tr>'}</tbody>
                </table>
            </div>

            <h4 style="margin-top: 1.5rem;">2. Borrowing Trends by Month</h4>
            <div style="overflow:auto;">
                <table>
                    <thead><tr><th>Month</th><th>Borrows</th></tr></thead>
                    <tbody>${monthRows || '<tr><td colspan="2">No data</td></tr>'}</tbody>
                </table>
            </div>

            <h4 style="margin-top: 1.5rem;">3. Borrowing Trends by Genre</h4>
            <div style="overflow:auto;">
                <table>
                    <thead><tr><th>Genre</th><th>Borrows</th></tr></thead>
                    <tbody>${genreRows || '<tr><td colspan="2">No data</td></tr>'}</tbody>
                </table>
            </div>

            <h4 style="margin-top: 1.5rem;">4. Top 10 Most Popular Books</h4>
            <div style="overflow:auto;">
                <table>
                    <thead><tr><th>#</th><th>Title</th><th>ISBN</th><th>Borrows</th><th>Availability</th></tr></thead>
                    <tbody>${bookRows || '<tr><td colspan="5">No data</td></tr>'}</tbody>
                </table>
            </div>

            <h4 style="margin-top: 1.5rem;">5. Active Members (Last 90 Days)</h4>
            <div style="overflow:auto;">
                <table>
                    <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Membership</th><th>Borrows</th></tr></thead>
                    <tbody>${memberRows || '<tr><td colspan="5">No data</td></tr>'}</tbody>
                </table>
            </div>

            <h4 style="margin-top: 1.5rem;">6. Overdue Books with Estimated Fines</h4>
            <div style="overflow:auto;">
                <table>
                    <thead><tr><th>Title</th><th>ISBN</th><th>Member</th><th>Due</th><th>Days Overdue</th><th>Est. Fine</th><th>Status</th></tr></thead>
                    <tbody>${overdueRows || '<tr><td colspan="7">No data</td></tr>'}</tbody>
                </table>
            </div>

            <details style="margin-top: 1.5rem;">
                <summary>Show raw text report</summary>
                <pre style="white-space: pre-wrap;">${esc(data.report || '')}</pre>
            </details>
        </div>
    `;
}



