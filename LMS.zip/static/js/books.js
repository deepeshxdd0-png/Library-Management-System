// Books page functionality
document.addEventListener('DOMContentLoaded', async () => {
    const isbnSearch = document.getElementById('isbn-search');
    isbnSearch.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            searchBook();
        }
    });
    await loadBooks();
});

function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alert-container');
    alertContainer.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    setTimeout(() => {
        alertContainer.innerHTML = '';
    }, 5000);
}

async function searchBook() {
    const isbn = document.getElementById('isbn-search').value.trim().toLowerCase();
    const resultsContainer = document.getElementById('book-results');
    
    // Show loading
    resultsContainer.innerHTML = '<div class="loading"><div class="spinner"></div><p>Loading books...</p></div>';
    try {
        const list = await getBooksList();
        const filtered = isbn ? list.filter(b => String(b.isbn).toLowerCase().includes(isbn)) : list;
        renderBookList(filtered);
        if (isbn) {
            showAlert(`Showing ${filtered.length} result(s) for "${isbn}"`, 'info');
        }
    } catch (error) {
        resultsContainer.innerHTML = `<div class="alert alert-danger">${error.message}</div>`;
    }
}

async function loadBooks() {
    const resultsContainer = document.getElementById('book-results');
    resultsContainer.innerHTML = '<div class="loading"><div class="spinner"></div><p>Loading books...</p></div>';
    try {
        const list = await getBooksList();
        renderBookList(list);
    } catch (error) {
        resultsContainer.innerHTML = `<div class="alert alert-danger">${error.message}</div>`;
    }
}

function renderBookList(books) {
    const resultsContainer = document.getElementById('book-results');
    if (!books || books.length === 0) {
        resultsContainer.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">📖</div>
                <h3>No Books Found</h3>
                <p>Try a different search.</p>
            </div>
        `;
        return;
    }
    const rows = books.map(b => `
        <tr>
            <td>${escapeHtml(b.isbn)}</td>
            <td>${escapeHtml(b.title)}</td>
            <td>${b.publication_year || 'N/A'}</td>
            <td>${b.available_copies}/${b.total_copies}</td>
        </tr>
    `).join('');
    resultsContainer.innerHTML = `
        <div class="card-header"><h3>Books (${books.length})</h3></div>
        <div style="overflow:auto;">
            <table>
                <thead>
                    <tr>
                        <th>ISBN</th>
                        <th>Title</th>
                        <th>Year</th>
                        <th>Availability</th>
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>
        </div>
    `;
}

async function getBooksList() {
    // Fallback if API.Book.listBooks is missing due to caching
    if (window.API && window.API.Book && typeof window.API.Book.listBooks === 'function') {
        return window.API.Book.listBooks();
    }
    const resp = await fetch('/api/books');
    if (!resp.ok) {
        throw new Error('Failed to load books');
    }
    return resp.json();
}

function escapeHtml(text) {
    if (text === null || text === undefined) return 'N/A';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}



