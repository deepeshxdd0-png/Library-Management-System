// API Configuration and Utility Functions
const API_BASE_URL = 'http://localhost:8000/api';

/**
 * Generic API request function
 */
async function apiRequest(endpoint, method = 'GET', data = null) {
    const options = {
        method,
        headers: {
            'Content-Type': 'application/json',
        },
    };

    if (data) {
        options.body = JSON.stringify(data);
    }

    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
        const result = await response.json();

        if (!response.ok) {
            let detail = result?.detail ?? result?.message ?? 'An error occurred';
            // Normalize Pydantic/validation error arrays to a readable string
            if (Array.isArray(detail)) {
                detail = detail.map(d => d?.msg || d?.message || JSON.stringify(d)).join('; ');
            } else if (typeof detail === 'object') {
                detail = detail.message || JSON.stringify(detail);
            }
            throw new Error(detail);
        }

        return result;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

/**
 * Book API functions
 */
const BookAPI = {
    getBook: (isbn) => apiRequest(`/books/${isbn}`),
    listBooks: () => apiRequest(`/books`),
};

/**
 * Member API functions
 */
const MemberAPI = {
    registerMember: (memberData) => apiRequest('/members', 'POST', memberData),
    getMember: (memberId) => apiRequest(`/members/${memberId}`),
    getMembers: () => apiRequest('/members'),
};

/**
 * Borrowing API functions
 */
const BorrowAPI = {
    borrowBook: (borrowData) => apiRequest('/borrow', 'POST', borrowData),
    returnBook: (returnData) => apiRequest('/return', 'POST', returnData),
    getBorrowings: (memberId) => apiRequest(`/borrowings/${memberId}`),
};

/**
 * Fines API functions
 */
const FinesAPI = {
    getFines: (memberId) => apiRequest(`/fines/${memberId}`),
    payFine: (fineData) => apiRequest('/fines/pay', 'POST', fineData),
};

/**
 * Health check
 */
const HealthAPI = {
    checkHealth: () => apiRequest('/health'),
};

// Export for use in other scripts
window.API = {
    Book: BookAPI,
    Member: MemberAPI,
    Borrow: BorrowAPI,
    Fines: FinesAPI,
    Health: HealthAPI,
};

/**
 * Utility function to show alert messages
 */
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    const container = document.querySelector('.container');
    container.insertBefore(alertDiv, container.firstChild);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

/**
 * Utility function to format date
 */
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

/**
 * Utility function to format currency
 */
function formatCurrency(amount) {
    return `$${parseFloat(amount).toFixed(2)}`;
}


