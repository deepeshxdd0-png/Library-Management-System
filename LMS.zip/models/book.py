"""Book model for the Library Management System."""

from typing import List, Optional


class Book:
    """
    Represents a book in the library system.
    
    Attributes:
        book_id: Unique identifier for the book
        isbn: International Standard Book Number
        title: Title of the book
        publication_year: Year the book was published
        genre: List of genres associated with the book
        synopsis: Brief description of the book
        total_copies: Total number of copies in the library
        available_copies: Number of copies currently available
        language: Primary language of the book
        publisher: Publisher of the book
        authors: List of Author objects associated with the book
    """
    
    def __init__(
        self,
        book_id: Optional[int] = None,
        isbn: str = "",
        title: str = "",
        publication_year: Optional[int] = None,
        genre: Optional[List[str]] = None,
        synopsis: str = "",
        total_copies: int = 1,
        available_copies: int = 1,
        language: str = "English",
        publisher: str = "",
        authors: Optional[List['Author']] = None
    ) -> None:
        """Initialize a Book instance."""
        self.book_id = book_id
        self.isbn = isbn
        self.title = title
        self.publication_year = publication_year
        self.genre = genre or []
        self.synopsis = synopsis
        self.total_copies = total_copies
        self.available_copies = available_copies
        self.language = language
        self.publisher = publisher
        self.authors = authors or []
    
    def is_available(self) -> bool:
        """
        Check if the book has available copies.
        
        Returns:
            True if available_copies > 0, False otherwise
        """
        return self.available_copies > 0
    
    def __repr__(self) -> str:
        """Return string representation of the book."""
        return f"Book(book_id={self.book_id}, isbn='{self.isbn}', title='{self.title}')"
    
    def __str__(self) -> str:
        """Return human-readable string representation."""
        authors_str = ", ".join([str(author) for author in self.authors]) if self.authors else "Unknown"
        return f"{self.title} by {authors_str} ({self.isbn})"
    
    def to_dict(self) -> dict:
        """
        Convert the book to a dictionary.
        
        Returns:
            Dictionary representation of the book
        """
        return {
            'book_id': self.book_id,
            'isbn': self.isbn,
            'title': self.title,
            'publication_year': self.publication_year,
            'genre': self.genre,
            'synopsis': self.synopsis,
            'total_copies': self.total_copies,
            'available_copies': self.available_copies,
            'language': self.language,
            'publisher': self.publisher,
            'authors': [author.to_dict() for author in self.authors] if self.authors else []
        }

