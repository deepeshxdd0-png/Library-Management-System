"""Member model for the Library Management System."""

from typing import Optional


class Member:
    """
    Represents a library member.
    
    Attributes:
        member_id: Unique identifier for the member
        first_name: Member's first name
        last_name: Member's last name
        email: Member's email address
        phone: Member's phone number
        address: Member's physical address
        membership_type: Type of membership (Standard, Premium, etc.)
        member_since: Timestamp when member joined
        status: Current membership status (Active, Inactive, Suspended)
        borrowing_limit: Maximum number of books that can be borrowed
    """
    
    def __init__(
        self,
        member_id: Optional[int] = None,
        first_name: str = "",
        last_name: str = "",
        email: str = "",
        phone: str = "",
        address: str = "",
        membership_type: str = "Standard",
        member_since: Optional[str] = None,
        status: str = "Active",
        borrowing_limit: int = 5
    ) -> None:
        """Initialize a Member instance."""
        self.member_id = member_id
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.phone = phone
        self.address = address
        self.membership_type = membership_type
        self.member_since = member_since
        self.status = status
        self.borrowing_limit = borrowing_limit
    
    @property
    def full_name(self) -> str:
        """
        Get the full name of the member.
        
        Returns:
            Full name string
        """
        return f"{self.first_name} {self.last_name}".strip()
    
    def is_active(self) -> bool:
        """
        Check if the member has an active status.
        
        Returns:
            True if status is 'Active', False otherwise
        """
        return self.status == "Active"
    
    def __repr__(self) -> str:
        """Return string representation of the member."""
        return f"Member(member_id={self.member_id}, name='{self.full_name}', email='{self.email}')"
    
    def __str__(self) -> str:
        """Return human-readable string representation."""
        return f"{self.full_name} ({self.email})"
    
    def to_dict(self) -> dict:
        """
        Convert the member to a dictionary.
        
        Returns:
            Dictionary representation of the member
        """
        from datetime import datetime
        member_since_str = None
        if isinstance(self.member_since, datetime):
            member_since_str = self.member_since.isoformat()
        elif self.member_since is not None:
            member_since_str = str(self.member_since)
        
        return {
            'member_id': self.member_id,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'email': self.email,
            'phone': self.phone,
            'address': self.address,
            'membership_type': self.membership_type,
            'member_since': member_since_str,
            'status': self.status,
            'borrowing_limit': self.borrowing_limit
        }

