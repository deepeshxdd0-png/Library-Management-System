"""Author model for the Library Management System."""

from typing import Optional


class Author:
    """
    Represents an author in the library system.
    
    Attributes:
        author_id: Unique identifier for the author
        first_name: Author's first name
        last_name: Author's last name
        birth_year: Year the author was born
        nationality: Author's nationality
        biography: Brief biography of the author
    """
    
    def __init__(
        self,
        author_id: Optional[int] = None,
        first_name: str = "",
        last_name: str = "",
        birth_year: Optional[int] = None,
        nationality: str = "",
        biography: str = ""
    ) -> None:
        """Initialize an Author instance."""
        self.author_id = author_id
        self.first_name = first_name
        self.last_name = last_name
        self.birth_year = birth_year
        self.nationality = nationality
        self.biography = biography
    
    @property
    def full_name(self) -> str:
        """
        Get the full name of the author.
        
        Returns:
            Full name string
        """
        return f"{self.first_name} {self.last_name}".strip()
    
    def __repr__(self) -> str:
        """Return string representation of the author."""
        return f"Author(author_id={self.author_id}, name='{self.full_name}')"
    
    def __str__(self) -> str:
        """Return human-readable string representation."""
        return self.full_name
    
    def __eq__(self, other) -> bool:
        """Check equality based on first and last name."""
        if not isinstance(other, Author):
            return False
        return self.first_name.lower() == other.first_name.lower() and \
               self.last_name.lower() == other.last_name.lower()
    
    def __hash__(self) -> int:
        """Return hash based on first and last name."""
        return hash((self.first_name.lower(), self.last_name.lower()))
    
    def to_dict(self) -> dict:
        """
        Convert the author to a dictionary.
        
        Returns:
            Dictionary representation of the author
        """
        return {
            'author_id': self.author_id,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'birth_year': self.birth_year,
            'nationality': self.nationality,
            'biography': self.biography
        }

