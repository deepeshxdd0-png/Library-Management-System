"""Pydantic models for API request/response validation."""

from pydantic import BaseModel, EmailStr, Field, validator
from typing import List, Optional, Dict, Any
from datetime import date


class MemberCreate(BaseModel):
    """Model for creating a new member."""
    first_name: str = Field(..., min_length=1, max_length=100, description="Member's first name")
    last_name: str = Field(..., min_length=1, max_length=100, description="Member's last name")
    email: EmailStr = Field(..., description="Member's email address")
    phone: Optional[str] = Field(None, max_length=20, description="Member's phone number")
    address: Optional[str] = Field(None, description="Member's physical address")
    membership_type: str = Field("Standard", description="Type of membership")
    borrowing_limit: int = Field(5, ge=0, le=10, description="Maximum books that can be borrowed")

    class Config:
        schema_extra = {
            "example": {
                "first_name": "Jane",
                "last_name": "Smith",
                "email": "jane.smith@example.com",
                "phone": "555-1234",
                "address": "456 Oak Avenue",
                "membership_type": "Premium",
                "borrowing_limit": 10
            }
        }


class MemberResponse(BaseModel):
    """Model for member response."""
    member_id: int
    first_name: str
    last_name: str
    email: str
    phone: Optional[str]
    address: Optional[str]
    membership_type: str
    member_since: Optional[str]
    status: str
    borrowing_limit: int

    class Config:
        orm_mode = True


class BorrowRequest(BaseModel):
    """Model for borrowing a book."""
    member_id: int = Field(..., description="ID of the member borrowing the book")
    isbn: str = Field(..., description="ISBN of the book to borrow")
    borrowing_period_days: int = Field(14, ge=1, le=90, description="Borrowing period in days")

    class Config:
        schema_extra = {
            "example": {
                "member_id": 1,
                "isbn": "9780141441146",
                "borrowing_period_days": 14
            }
        }


class BorrowResponse(BaseModel):
    """Model for borrowing response."""
    log_id: int
    member_id: int
    isbn: str
    borrow_date: str
    due_date: str
    status: str


class ReturnRequest(BaseModel):
    """Model for returning a book."""
    log_id: int = Field(..., description="ID of the borrowing log entry")

    class Config:
        schema_extra = {
            "example": {
                "log_id": 1
            }
        }


class ReturnResponse(BaseModel):
    """Model for return response."""
    log_id: int
    return_date: str
    status: str
    fine_charged: bool
    fine_id: Optional[int] = None


class FineDetails(BaseModel):
    """Model for fine details."""
    fine_id: int
    log_id: int
    member_id: int
    amount: float
    fine_rate_per_day: float
    days_overdue: int
    calculation_date: str
    status: str
    payment_date: Optional[str]
    title: str
    isbn: str
    due_date: str
    return_date: Optional[str]


class FinePayRequest(BaseModel):
    """Model for paying a fine."""
    fine_id: int = Field(..., description="ID of the fine to pay")

    class Config:
        schema_extra = {
            "example": {
                "fine_id": 1
            }
        }


class AuthorDetails(BaseModel):
    """Model for author details."""
    author_id: Optional[int]
    first_name: str
    last_name: str
    birth_year: Optional[int]
    nationality: Optional[str]
    biography: Optional[str]


class BookDetails(BaseModel):
    """Model for book details."""
    book_id: int
    isbn: str
    title: str
    publication_year: Optional[int]
    genre: List[str]
    synopsis: Optional[str]
    total_copies: int
    available_copies: int
    language: str
    publisher: Optional[str]
    authors: List[AuthorDetails]


class ErrorResponse(BaseModel):
    """Model for error responses."""
    error: str
    detail: Optional[str] = None
    status_code: int


class MessageResponse(BaseModel):
    """Model for simple message responses."""
    message: str
    status: str


class BorrowingLogDetails(BaseModel):
    """Model for borrowing log details."""
    log_id: int
    member_id: int
    book_id: int
    title: str
    isbn: str
    borrow_date: str
    due_date: str
    return_date: Optional[str]
    status: str

