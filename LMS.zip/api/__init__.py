"""API package for Library Management System."""

