"""FastAPI routes for Library Management System."""

from fastapi import APIRouter, HTTPException, status, Query
from fastapi.responses import FileResponse
from typing import List

from api.models import (
    MemberCreate, MemberResponse, BorrowRequest, BorrowResponse,
    ReturnRequest, ReturnResponse, FineDetails, FinePayRequest,
    BookDetails, ErrorResponse, MessageResponse
)
from database.exceptions import (
    BookNotAvailableError,
    BorrowLimitExceededError,
    BookNotFoundError,
    MemberNotFoundError,
    DatabaseError
)

router = APIRouter()


# Global variable to store library instance (will be set in main.py)
library = None


def set_library(lib):
    """Set the library instance for routes."""
    global library
    library = lib


@router.post("/members", response_model=MemberResponse, status_code=status.HTTP_201_CREATED)
def register_member(member: MemberCreate):
    """
    Register a new library member.
    
    Creates a new member account with the provided information.
    """
    if not library:
        raise HTTPException(status_code=500, detail="Library not initialized")
    
    try:
        from models.member import Member
        
        new_member = Member(
            first_name=member.first_name,
            last_name=member.last_name,
            email=member.email,
            phone=member.phone,
            address=member.address,
            membership_type=member.membership_type,
            borrowing_limit=member.borrowing_limit
        )
        
        member_id = library.register_member(new_member)
        registered_member = library.get_member(member_id)
        
        return MemberResponse(**registered_member.to_dict())
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to register member: {str(e)}"
        )


@router.get("/books/{isbn}", response_model=BookDetails)
def get_book(isbn: str):
    """
    Retrieve book details by ISBN.
    
    Returns complete information about the book including authors and availability.
    """
    if not library:
        raise HTTPException(status_code=500, detail="Library not initialized")
    
    book = library.get_book(isbn)
    
    if not book:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Book with ISBN {isbn} not found"
        )
    
    return BookDetails(**book.to_dict())


@router.get("/books", response_model=List)
def list_books():
    """
    List books with basic details for catalog views.
    """
    if not library:
        raise HTTPException(status_code=500, detail="Library not initialized")

    query = """
        SELECT b.isbn, b.title, b.publication_year, b.available_copies, b.total_copies
        FROM Books b
        ORDER BY b.title
    """
    results = library.db.execute_query(query, fetch=True) or []
    return results


@router.post("/borrow", response_model=BorrowResponse, status_code=status.HTTP_201_CREATED)
def borrow_book(borrow_req: BorrowRequest):
    """
    Borrow a book with full transactional integrity.
    
    Checks availability, member status, and borrowing limits atomically.
    All operations are performed within a single transaction.
    """
    if not library:
        raise HTTPException(status_code=500, detail="Library not initialized")
    
    try:
        result = library.borrow_book(
            member_id=borrow_req.member_id,
            isbn=borrow_req.isbn,
            borrowing_period_days=borrow_req.borrowing_period_days
        )
        
        return BorrowResponse(**result)
    
    except BookNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    
    except BookNotAvailableError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    
    except MemberNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    
    except BorrowLimitExceededError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    
    except DatabaseError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.post("/return", response_model=ReturnResponse)
def return_book(return_req: ReturnRequest):
    """
    Return a book and calculate fines if overdue.
    
    Automatically calculates and records fines for overdue books.
    """
    if not library:
        raise HTTPException(status_code=500, detail="Library not initialized")
    
    try:
        result = library.return_book(return_req.log_id)
        return ReturnResponse(**result)
    
    except DatabaseError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/fines/{member_id}", response_model=List[FineDetails])
def get_fines(member_id: int):
    """
    Get all outstanding fines for a member.
    
    Returns detailed information about unpaid fines including book details.
    """
    if not library:
        raise HTTPException(status_code=500, detail="Library not initialized")
    
    fines = library.get_fines(member_id)
    
    if not fines:
        return []
    
    return [FineDetails(**fine) for fine in fines]


@router.post("/fines/pay", response_model=MessageResponse)
def pay_fine(fine_pay: FinePayRequest):
    """
    Pay a fine.
    
    Marks the specified fine as paid and records the payment date.
    """
    if not library:
        raise HTTPException(status_code=500, detail="Library not initialized")
    
    try:
        library.pay_fine(fine_pay.fine_id)
        return MessageResponse(
            message=f"Fine {fine_pay.fine_id} paid successfully",
            status="success"
        )
    except DatabaseError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/borrowings/{member_id}", response_model=List)
def get_current_borrowings(member_id: int):
    """
    Get currently borrowed books for a member.
    
    Returns list of all books currently borrowed by the member.
    """
    if not library:
        raise HTTPException(status_code=500, detail="Library not initialized")
    
    borrowings = library.get_current_borrowings(member_id)
    return borrowings


@router.get("/health", response_model=MessageResponse)
def health_check():
    """
    Health check endpoint.
    
    Returns API status.
    """
    return MessageResponse(
        message="Library Management System API is running",
        status="healthy"
    )


@router.get("/members", response_model=List)
def list_members():
    """
    List members with basic details for selection/autocomplete.
    """
    if not library:
        raise HTTPException(status_code=500, detail="Library not initialized")

    query = """
        SELECT member_id, first_name, last_name, email
        FROM Members
        ORDER BY member_id DESC
        LIMIT 500
    """
    results = library.db.execute_query(query, fetch=True) or []
    return results


@router.get("/generate-report")
def generate_report(format: str = Query(default="file", pattern="^(file|json)$")):
    """
    Generate the analytics report and return it as a text file.
    """
    if not library:
        raise HTTPException(status_code=500, detail="Library not initialized")

    try:
        from analytics.reporting import AnalyticsReporter

        reporter = AnalyticsReporter(library.db)
        output_file = reporter.generate_full_report("report.txt")
        if format == "json":
            # Build structured sections for rich UI rendering
            sections = {
                "top_authors": reporter.get_top_prolific_authors(5),
                "monthly_trends": reporter.get_borrowing_trends_by_month(),
                "genre_trends": reporter.get_borrowing_trends_by_genre(),
                "popular_books": reporter.get_most_popular_books(10),
                "active_members": reporter.get_active_members(days=90, min_borrows=3),
                "overdue_books": reporter.get_overdue_books_with_fines(),
            }
            with open(output_file, 'r', encoding='utf-8') as f:
                content = f.read()
            return {"report": content, "sections": sections}
        return FileResponse(path=output_file, media_type="text/plain", filename="report.txt")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate report: {e}")

