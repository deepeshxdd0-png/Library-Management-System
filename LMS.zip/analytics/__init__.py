"""Analytics package for Library Management System."""

