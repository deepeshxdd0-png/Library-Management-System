"""Analytics and reporting module for Library Management System."""

import logging
from typing import List, Dict
from datetime import date, timedelta
from database.db_manager import DBManager

logger = logging.getLogger(__name__)


class AnalyticsReporter:
    """
    Analytics reporter for generating comprehensive library statistics.
    
    Generates reports on:
    - Top prolific authors
    - Borrowing trends by month and genre
    - Most popular books
    - Active members
    - Overdue books with fines
    """
    
    def __init__(self, db_manager: DBManager):
        """
        Initialize the AnalyticsReporter.
        
        Args:
            db_manager: DBManager instance for database access
        """
        self.db = db_manager
        logger.info("AnalyticsReporter initialized")
    
    def get_top_prolific_authors(self, limit: int = 5) -> List[Dict]:
        """
        Get top prolific authors by book count.
        
        Args:
            limit: Number of top authors to return
            
        Returns:
            List of dictionaries with author statistics
        """
        query = """
            SELECT 
                a.author_id,
                a.first_name,
                a.last_name,
                a.nationality,
                COUNT(DISTINCT ba.book_id) as book_count
            FROM Authors a
            JOIN BookAuthors ba ON a.author_id = ba.author_id
            GROUP BY a.author_id, a.first_name, a.last_name, a.nationality
            ORDER BY book_count DESC
            LIMIT %s
        """
        results = self.db.execute_query(query, (limit,), fetch=True)
        logger.info(f"Retrieved top {limit} prolific authors")
        return results or []
    
    def get_borrowing_trends_by_month(self) -> List[Dict]:
        """
        Get borrowing trends aggregated by month.
        
        Returns:
            List of dictionaries with monthly borrowing statistics
        """
        query = """
            SELECT 
                DATE_TRUNC('month', borrow_date) as month,
                COUNT(*) as borrow_count
            FROM BorrowingLog
            GROUP BY DATE_TRUNC('month', borrow_date)
            ORDER BY month DESC
            LIMIT 12
        """
        results = self.db.execute_query(query, fetch=True)
        logger.info("Retrieved borrowing trends by month")
        return results or []
    
    def get_borrowing_trends_by_genre(self) -> List[Dict]:
        """
        Get borrowing trends aggregated by genre.
        
        Returns:
            List of dictionaries with genre-based borrowing statistics
        """
        query = """
            SELECT 
                genre_item as genre,
                COUNT(DISTINCT bl.log_id) as borrow_count
            FROM BorrowingLog bl
            JOIN Books b ON bl.book_id = b.book_id
            CROSS JOIN LATERAL unnest(b.genre) as genre_item
            GROUP BY genre_item
            ORDER BY borrow_count DESC
        """
        results = self.db.execute_query(query, fetch=True)
        logger.info("Retrieved borrowing trends by genre")
        return results or []
    
    def get_most_popular_books(self, limit: int = 10) -> List[Dict]:
        """
        Get most popular books by borrowing frequency.
        
        Args:
            limit: Number of top books to return
            
        Returns:
            List of dictionaries with book popularity statistics
        """
        query = """
            SELECT 
                b.book_id,
                b.isbn,
                b.title,
                COUNT(bl.log_id) as borrow_count,
                b.available_copies,
                b.total_copies
            FROM Books b
            LEFT JOIN BorrowingLog bl ON b.book_id = bl.book_id
            GROUP BY b.book_id, b.isbn, b.title, b.available_copies, b.total_copies
            ORDER BY borrow_count DESC, b.title
            LIMIT %s
        """
        results = self.db.execute_query(query, (limit,), fetch=True)
        logger.info(f"Retrieved top {limit} most popular books")
        return results or []
    
    def get_active_members(
        self,
        days: int = 90,
        min_borrows: int = 3
    ) -> List[Dict]:
        """
        Get active members who borrowed more than N books in the last N days.
        
        Args:
            days: Number of days to look back
            min_borrows: Minimum number of borrows to be considered active
            
        Returns:
            List of dictionaries with active member statistics
        """
        query = """
            SELECT 
                m.member_id,
                m.first_name,
                m.last_name,
                m.email,
                m.membership_type,
                m.status,
                COUNT(bl.log_id) as recent_borrows
            FROM Members m
            JOIN BorrowingLog bl ON m.member_id = bl.member_id
            WHERE bl.borrow_date >= CURRENT_DATE - INTERVAL '%s days'
                AND bl.borrow_date <= CURRENT_DATE
            GROUP BY m.member_id, m.first_name, m.last_name, m.email, 
                     m.membership_type, m.status
            HAVING COUNT(bl.log_id) >= %s
            ORDER BY recent_borrows DESC
        """
        results = self.db.execute_query(query, (days, min_borrows), fetch=True)
        logger.info(f"Retrieved active members (last {days} days)")
        return results or []
    
    def get_overdue_books_with_fines(self) -> List[Dict]:
        """
        Get all currently overdue books with calculated fines.
        
        Returns:
            List of dictionaries with overdue book details and estimated fines
        """
        query = """
            SELECT 
                bl.log_id,
                b.book_id,
                b.isbn,
                b.title,
                m.member_id,
                m.first_name || ' ' || m.last_name as member_name,
                m.email as member_email,
                bl.borrow_date,
                bl.due_date,
                bl.return_date,
                CURRENT_DATE - bl.due_date as days_overdue,
                (CURRENT_DATE - bl.due_date) * COALESCE(
                    (SELECT fine_rate_per_day FROM Fines WHERE log_id = bl.log_id LIMIT 1),
                    0.50
                ) as estimated_fine,
                COALESCE(f.status, 'Unfined') as fine_status
            FROM BorrowingLog bl
            JOIN Books b ON bl.book_id = b.book_id
            JOIN Members m ON bl.member_id = m.member_id
            LEFT JOIN Fines f ON bl.log_id = f.log_id
            WHERE bl.due_date < CURRENT_DATE
                AND bl.status IN ('Borrowed', 'Overdue')
                AND bl.return_date IS NULL
            ORDER BY days_overdue DESC
        """
        results = self.db.execute_query(query, fetch=True)
        logger.info("Retrieved overdue books with fines")
        return results or []
    
    def generate_full_report(self, output_file: str = "report.txt") -> str:
        """
        Generate a comprehensive analytics report.
        
        Args:
            output_file: Path to output file
            
        Returns:
            Path to generated report file
        """
        logger.info("Generating comprehensive analytics report")
        
        lines = []
        lines.append("=" * 80)
        lines.append("LIBRARY MANAGEMENT SYSTEM - COMPREHENSIVE ANALYTICS REPORT")
        lines.append("=" * 80)
        lines.append(f"Generated on: {date.today().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("")
        
        # 1. Top Prolific Authors
        lines.append("-" * 80)
        lines.append("1. TOP 5 MOST PROLIFIC AUTHORS")
        lines.append("-" * 80)
        authors = self.get_top_prolific_authors(5)
        if authors:
            for idx, author in enumerate(authors, 1):
                lines.append(f"{idx}. {author['first_name']} {author['last_name']}")
                lines.append(f"   Nationality: {author.get('nationality', 'Unknown')}")
                lines.append(f"   Book Count: {author['book_count']}")
                lines.append("")
        else:
            lines.append("No author data available.")
            lines.append("")
        
        # 2. Borrowing Trends by Month
        lines.append("-" * 80)
        lines.append("2. BORROWING TRENDS BY MONTH")
        lines.append("-" * 80)
        monthly_trends = self.get_borrowing_trends_by_month()
        if monthly_trends:
            for trend in monthly_trends:
                month_str = str(trend['month'])[:10] if trend.get('month') else 'Unknown'
                lines.append(f"{month_str}: {trend['borrow_count']} borrows")
            lines.append("")
        else:
            lines.append("No borrowing data available.")
            lines.append("")
        
        # 3. Borrowing Trends by Genre
        lines.append("-" * 80)
        lines.append("3. BORROWING TRENDS BY GENRE")
        lines.append("-" * 80)
        genre_trends = self.get_borrowing_trends_by_genre()
        if genre_trends:
            for trend in genre_trends:
                genre_name = trend['genre'] or 'Unspecified'
                lines.append(f"{genre_name}: {trend['borrow_count']} borrows")
            lines.append("")
        else:
            lines.append("No genre data available.")
            lines.append("")
        
        # 4. Most Popular Books
        lines.append("-" * 80)
        lines.append("4. TOP 10 MOST POPULAR BOOKS (BY BORROWING FREQUENCY)")
        lines.append("-" * 80)
        popular_books = self.get_most_popular_books(10)
        if popular_books:
            for idx, book in enumerate(popular_books, 1):
                lines.append(f"{idx}. {book['title']}")
                lines.append(f"   ISBN: {book['isbn']}")
                lines.append(f"   Borrow Count: {book['borrow_count']}")
                lines.append(f"   Availability: {book['available_copies']}/{book['total_copies']}")
                lines.append("")
        else:
            lines.append("No book data available.")
            lines.append("")
        
        # 5. Active Members
        lines.append("-" * 80)
        lines.append("5. ACTIVE MEMBERS (Last 90 Days, 3+ Borrows)")
        lines.append("-" * 80)
        active_members = self.get_active_members(days=90, min_borrows=3)
        if active_members:
            for idx, member in enumerate(active_members, 1):
                lines.append(f"{idx}. {member['first_name']} {member['last_name']}")
                lines.append(f"   Email: {member['email']}")
                lines.append(f"   Membership: {member['membership_type']}")
                lines.append(f"   Recent Borrows: {member['recent_borrows']}")
                lines.append("")
        else:
            lines.append("No active members found.")
            lines.append("")
        
        # 6. Overdue Books with Fines
        lines.append("-" * 80)
        lines.append("6. OVERDUE BOOKS WITH CALCULATED FINES")
        lines.append("-" * 80)
        overdue_books = self.get_overdue_books_with_fines()
        if overdue_books:
            for idx, book in enumerate(overdue_books, 1):
                lines.append(f"{idx}. {book['title']}")
                lines.append(f"   ISBN: {book['isbn']}")
                lines.append(f"   Member: {book['member_name']} ({book['member_email']})")
                lines.append(f"   Borrowed: {book['borrow_date']}")
                lines.append(f"   Due Date: {book['due_date']}")
                lines.append(f"   Days Overdue: {book['days_overdue']}")
                lines.append(f"   Estimated Fine: ${book['estimated_fine']:.2f}")
                lines.append(f"   Fine Status: {book['fine_status']}")
                lines.append("")
        else:
            lines.append("No overdue books found.")
            lines.append("")
        
        lines.append("=" * 80)
        lines.append("END OF REPORT")
        lines.append("=" * 80)
        
        # Write to file
        report_content = "\n".join(lines)
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        logger.info(f"Report generated successfully: {output_file}")
        return output_file
    
    def close(self):
        """Close the reporter."""
        logger.info("AnalyticsReporter closed")


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    db_manager = DBManager()
    reporter = AnalyticsReporter(db_manager)
    
    # Generate full report
    report_file = reporter.generate_full_report()
    print(f"\nReport generated: {report_file}")
    
    reporter.close()

