"""Scraper package for Library Management System."""
from scraper.scraper import BookScraper

__all__ = ['BookScraper']

