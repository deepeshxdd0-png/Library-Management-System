"""Web scraper for book data acquisition."""

import requests
from bs4 import BeautifulSoup
import time
import logging
from typing import List, Dict, Optional
import re

logger = logging.getLogger(__name__)


class BookScraper:
    """
    Web scraper for extracting book information from public sources.
    
    This scraper is designed to extract book data from Project Gutenberg
    or similar public domain book repositories.
    """
    
    def __init__(self, base_url: str = "https://www.gutenberg.org"):
        """
        Initialize the BookScraper.
        
        Args:
            base_url: Base URL of the book repository
        """
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def _make_request(self, url: str, max_retries: int = 3) -> Optional[BeautifulSoup]:
        """
        Make an HTTP request and parse the response.
        
        Args:
            url: URL to request
            max_retries: Maximum number of retry attempts
            
        Returns:
            BeautifulSoup object or None if request fails
        """
        for attempt in range(max_retries):
            try:
                response = self.session.get(url, timeout=10)
                response.raise_for_status()
                return BeautifulSoup(response.content, 'lxml')
            except requests.exceptions.RequestException as e:
                logger.warning(f"Attempt {attempt + 1} failed for {url}: {e}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                else:
                    logger.error(f"Failed to fetch {url} after {max_retries} attempts")
                    return None
        return None
    
    def extract_isbn(self, text: str) -> Optional[str]:
        """
        Extract ISBN from text using regex.
        
        Args:
            text: Text to search for ISBN
            
        Returns:
            ISBN string or None if not found
        """
        # Pattern for ISBN-10 and ISBN-13
        isbn_patterns = [
            r'ISBN[- ]*(?:13)?:?\s*978[- ]*\d{1,5}[- ]*\d{1,7}[- ]*\d{1,6}[- ]*\d',
            r'ISBN[- ]*(?:10)?:?\s*\d{1,5}[- ]*\d{1,7}[- ]*\d{1,6}[- ]*\d',
        ]
        
        for pattern in isbn_patterns:
            match = re.search(pattern, text)
            if match:
                isbn = re.sub(r'[^\dX]', '', match.group(0))
                if len(isbn) == 10 or len(isbn) == 13:
                    return isbn
        return None
    
    def extract_publication_year(self, text: str) -> Optional[int]:
        """
        Extract publication year from text.
        
        Args:
            text: Text to search for year
            
        Returns:
            Year as integer or None if not found
        """
        years = re.findall(r'\b(19|20)\d{2}\b', text)
        if years:
            # Return the most recent year that makes sense
            try:
                return int(years[-1])
            except (ValueError, IndexError):
                return None
        return None
    
    def parse_bibliographic_record(self, soup: BeautifulSoup, book_id: int) -> Dict:
        """
        Parse bibliographic record from Project Gutenberg page.
        
        Args:
            soup: BeautifulSoup object of the book page
            book_id: Book identifier
            
        Returns:
            Dictionary containing book information
        """
        book_data = {
            'title': '',
            'authors': [],
            'publication_year': None,
            'isbn': '',
            'genre': [],
            'synopsis': '',
            'language': 'English',
            'publisher': 'Project Gutenberg'
        }
        
        try:
            # Extract title
            title_elem = soup.find('h1') or soup.find('title')
            if title_elem:
                book_data['title'] = title_elem.get_text().strip()
            
            # Extract authors (common patterns)
            author_meta = soup.find('meta', {'name': 'author'})
            if author_meta and author_meta.get('content'):
                authors_text = author_meta['content']
                # Handle multiple authors separated by commas or semicolons
                authors = re.split(r'[,;]', authors_text)
                book_data['authors'] = [author.strip() for author in authors if author.strip()]
            
            # Extract publication year
            year_meta = soup.find('meta', {'name': 'publication-date'})
            if year_meta:
                try:
                    book_data['publication_year'] = int(year_meta.get('content', '').split('-')[0])
                except ValueError:
                    pass
            
            # Extract synopsis/description
            desc_elem = soup.find('meta', {'name': 'description'})
            if desc_elem:
                book_data['synopsis'] = desc_elem.get('content', '').strip()
            
            # Extract genre tags if available
            genre_links = soup.find_all('a', {'href': re.compile(r'/ebooks/subjects/')})
            if genre_links:
                book_data['genre'] = [link.get_text().strip() for link in genre_links[:5]]
            
            # Try to extract ISBN from full page text
            page_text = soup.get_text()
            isbn = self.extract_isbn(page_text)
            if isbn:
                book_data['isbn'] = isbn
            else:
                # Generate a pseudo-ISBN for books without one
                book_data['isbn'] = f"PG{book_id:06d}"
            
            # If no publication year found, try to extract from page text
            if not book_data['publication_year']:
                year = self.extract_publication_year(page_text)
                if year:
                    book_data['publication_year'] = year
            
            # Ensure we have at least basic data
            if not book_data['title']:
                book_data['title'] = f"Book {book_id}"
            if not book_data['authors']:
                book_data['authors'] = ['Unknown Author']
                
        except Exception as e:
            logger.error(f"Error parsing bibliographic record: {e}")
        
        return book_data
    
    def scrape_books(self, start_id: int = 1, end_id: int = 100, limit: int = 50) -> List[Dict]:
        """
        Scrape books from the repository.
        
        Args:
            start_id: Starting book ID
            end_id: Ending book ID
            limit: Maximum number of books to scrape
            
        Returns:
            List of dictionaries containing book information
        """
        books = []
        scraped_count = 0
        
        logger.info(f"Starting to scrape books from {self.base_url}")
        
        for book_id in range(start_id, end_id + 1):
            if scraped_count >= limit:
                break
            
            url = f"{self.base_url}/ebooks/{book_id}"
            logger.debug(f"Scraping book {book_id} from {url}")
            
            soup = self._make_request(url)
            if soup:
                book_data = self.parse_bibliographic_record(soup, book_id)
                if book_data:
                    books.append(book_data)
                    scraped_count += 1
                    logger.info(f"Successfully scraped: {book_data['title']}")
            
            # Be respectful: add delay between requests
            time.sleep(1)
        
        logger.info(f"Scraped {len(books)} books successfully")
        return books
    
    def scrape_from_catalog(self, limit: int = 50) -> List[Dict]:
        """
        Scrape books from the popular/recent catalog.
        
        Args:
            limit: Maximum number of books to scrape
            
        Returns:
            List of dictionaries containing book information
        """
        books = []
        
        # Project Gutenberg doesn't have a straightforward catalog API
        # So we'll use a predefined list of popular book IDs
        popular_books = [
            11, 84, 1342, 1513, 161, 1952, 74, 164, 15384, 6761,
            2701, 16328, 1080, 35, 844, 2600, 98, 158, 6130, 1232,
            4300, 2591, 43, 174, 2327, 100, 28054, 1184, 120, 973,
            30254, 4085, 514, 408, 3207, 1260, 718, 2590, 84, 43,
            2500, 28054, 2701, 16328, 100, 6130, 174, 15384, 161, 6761
        ]
        
        logger.info(f"Scraping popular books catalog")
        
        for book_id in popular_books[:limit]:
            url = f"{self.base_url}/ebooks/{book_id}"
            soup = self._make_request(url)
            
            if soup:
                book_data = self.parse_bibliographic_record(soup, book_id)
                if book_data:
                    books.append(book_data)
                    logger.info(f"Successfully scraped: {book_data['title']}")
            
            time.sleep(0.5)
        
        logger.info(f"Scraped {len(books)} books from catalog")
        return books


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    scraper = BookScraper()
    books = scraper.scrape_from_catalog(limit=10)
    print(f"\nScraped {len(books)} books:")
    for book in books:
        print(f"- {book['title']} by {', '.join(book['authors'])} ({book['isbn']})")

