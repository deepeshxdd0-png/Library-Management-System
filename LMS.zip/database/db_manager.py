"""Database manager with transactional integrity for Library Management System."""

import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2.pool import SimpleConnectionPool
from contextlib import contextmanager
from typing import List, Dict, Optional, Tuple
import logging
from datetime import date, datetime, timedelta

from database.exceptions import (
    BookNotAvailableError,
    BorrowLimitExceededError,
    BookNotFoundError,
    MemberNotFoundError,
    DatabaseError,
    DuplicateISBNError
)
from models.book import Book
from models.author import Author
from models.member import Member

logger = logging.getLogger(__name__)


class DBManager:
    """
    Database Manager for handling all database operations with transactional integrity.
    
    This class provides methods for managing books, authors, members, borrowing,
    and fines with proper transaction handling and error recovery.
    """
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 5432,
        database: str = "library_db",
        user: str = "postgres",
        password: str = "Deepesh@123",
        min_connections: int = 1,
        max_connections: int = 10
    ):
        """
        Initialize the DBManager with connection pool.
        
        Args:
            host: Database host
            port: Database port
            database: Database name
            user: Database user
            password: Database password
            min_connections: Minimum pool connections
            max_connections: Maximum pool connections
        """
        self.db_config = {
            'host': host,
            'port': port,
            'database': database,
            'user': user,
            'password': password
        }
        
        try:
            self.pool = SimpleConnectionPool(
                min_connections,
                max_connections,
                **self.db_config
            )
            logger.info("Database connection pool created successfully")
        except Exception as e:
            logger.error(f"Failed to create connection pool: {e}")
            raise DatabaseError(f"Database connection failed: {e}")
    
    @contextmanager
    def get_connection(self):
        """
        Context manager for database connections.
        
        Yields:
            Connection object from the pool
        """
        conn = self.pool.getconn()
        try:
            yield conn
        finally:
            self.pool.putconn(conn)
    
    @contextmanager
    def transaction(self):
        """
        Context manager for database transactions.
        
        Automatically commits on success or rolls back on error.
        """
        conn = self.pool.getconn()
        try:
            yield conn
            conn.commit()
            logger.debug("Transaction committed successfully")
        except Exception as e:
            conn.rollback()
            logger.error(f"Transaction rolled back due to error: {e}")
            raise
        finally:
            self.pool.putconn(conn)
    
    def execute_query(
        self,
        query: str,
        params: Optional[Tuple] = None,
        fetch: bool = False
    ) -> Optional[List[Dict]]:
        """
        Execute a query with optional parameterization.
        
        Args:
            query: SQL query to execute
            params: Query parameters
            fetch: Whether to fetch results
            
        Returns:
            Query results if fetch=True, None otherwise
        """
        with self.get_connection() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(query, params)
                if fetch:
                    return [dict(row) for row in cur.fetchall()]
                conn.commit()
                return None
    
    def insert_author(self, author: Author) -> int:
        """
        Insert an author into the database.
        
        Args:
            author: Author object to insert
            
        Returns:
            Generated author_id
        """
        with self.transaction() as conn:
            with conn.cursor() as cur:
                query = """
                    INSERT INTO Authors (first_name, last_name, birth_year, nationality, biography)
                    VALUES (%s, %s, %s, %s, %s)
                    ON CONFLICT (first_name, last_name) DO UPDATE
                    SET updated_at = CURRENT_TIMESTAMP
                    RETURNING author_id
                """
                cur.execute(query, (
                    author.first_name,
                    author.last_name,
                    author.birth_year,
                    author.nationality,
                    author.biography
                ))
                result = cur.fetchone()
                if result:
                    author_id = result[0]
                    logger.info(f"Author inserted/updated: {author.full_name} (ID: {author_id})")
                    return author_id
                raise DatabaseError("Failed to insert author")
    
    def insert_book(self, book: Book) -> int:
        """
        Insert a book into the database.
        
        Args:
            book: Book object to insert
            
        Returns:
            Generated book_id
        """
        with self.transaction() as conn:
            with conn.cursor() as cur:
                # Check for duplicate ISBN
                cur.execute("SELECT book_id FROM Books WHERE isbn = %s", (book.isbn,))
                if cur.fetchone():
                    raise DuplicateISBNError(f"Book with ISBN {book.isbn} already exists")
                
                query = """
                    INSERT INTO Books (isbn, title, publication_year, genre, synopsis,
                                     total_copies, available_copies, language, publisher)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING book_id
                """
                cur.execute(query, (
                    book.isbn,
                    book.title,
                    book.publication_year,
                    book.genre,
                    book.synopsis,
                    book.total_copies,
                    book.available_copies,
                    book.language,
                    book.publisher
                ))
                result = cur.fetchone()
                if not result:
                    raise DatabaseError("Failed to insert book")
                
                book_id = result[0]
                logger.info(f"Book inserted: {book.title} (ID: {book_id}, ISBN: {book.isbn})")
                
                # Insert book-author relationships
                if book.authors:
                    author_ids = []
                    for author in book.authors:
                        author_id = self.insert_author(author)
                        author_ids.append(author_id)
                    
                    for author_id in author_ids:
                        cur.execute("""
                            INSERT INTO BookAuthors (book_id, author_id)
                            VALUES (%s, %s)
                            ON CONFLICT DO NOTHING
                        """, (book_id, author_id))
                
                return book_id
    
    def insert_member(self, member: Member) -> int:
        """
        Insert a member into the database.
        
        Args:
            member: Member object to insert
            
        Returns:
            Generated member_id
        """
        with self.transaction() as conn:
            with conn.cursor() as cur:
                query = """
                    INSERT INTO Members (first_name, last_name, email, phone, address,
                                        membership_type, status, borrowing_limit)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING member_id
                """
                cur.execute(query, (
                    member.first_name,
                    member.last_name,
                    member.email,
                    member.phone,
                    member.address,
                    member.membership_type,
                    member.status,
                    member.borrowing_limit
                ))
                result = cur.fetchone()
                if not result:
                    raise DatabaseError("Failed to insert member")
                
                member_id = result[0]
                logger.info(f"Member inserted: {member.full_name} (ID: {member_id})")
                return member_id
    
    def get_book_by_isbn(self, isbn: str) -> Optional[Book]:
        """
        Retrieve a book by ISBN.
        
        Args:
            isbn: ISBN to search for
            
        Returns:
            Book object or None if not found
        """
        query = """
            SELECT b.*
            FROM Books b
            WHERE b.isbn = %s
        """
        results = self.execute_query(query, (isbn,), fetch=True)
        
        if not results:
            return None
        
        row = results[0]
        book = Book(
            book_id=row['book_id'],
            isbn=row['isbn'],
            title=row['title'],
            publication_year=row['publication_year'],
            genre=row['genre'] if row['genre'] else [],
            synopsis=row['synopsis'],
            total_copies=row['total_copies'],
            available_copies=row['available_copies'],
            language=row['language'],
            publisher=row['publisher']
        )
        
        # Fetch authors
        author_query = """
            SELECT a.author_id, a.first_name, a.last_name, a.birth_year, a.nationality, a.biography
            FROM Authors a
            JOIN BookAuthors ba ON a.author_id = ba.author_id
            WHERE ba.book_id = %s
        """
        authors_data = self.execute_query(author_query, (book.book_id,), fetch=True)
        book.authors = [Author(**dict(a)) for a in authors_data]
        
        return book
    
    def get_member(self, member_id: int) -> Optional[Member]:
        """
        Retrieve a member by ID.
        
        Args:
            member_id: Member ID to search for
            
        Returns:
            Member object or None if not found
        """
        query = """
            SELECT member_id, first_name, last_name, email, phone, address, 
                   membership_type, member_since, status, borrowing_limit
            FROM Members WHERE member_id = %s
        """
        results = self.execute_query(query, (member_id,), fetch=True)
        
        if not results:
            return None
        
        row = results[0]
        return Member(**dict(row))
    
    def get_current_borrowings_count(self, member_id: int) -> int:
        """
        Get the count of currently borrowed books for a member.
        
        Args:
            member_id: Member ID
            
        Returns:
            Number of currently borrowed books
        """
        query = """
            SELECT COUNT(*) as count
            FROM BorrowingLog
            WHERE member_id = %s AND status IN ('Borrowed', 'Overdue')
        """
        results = self.execute_query(query, (member_id,), fetch=True)
        if results:
            return results[0]['count']
        return 0
    
    def borrow_book(
        self,
        member_id: int,
        isbn: str,
        borrowing_period_days: int = 14
    ) -> int:
        """
        Atomically borrow a book with full transactional integrity.
        
        This method performs the following operations atomically:
        1. Check if book exists and is available
        2. Check if member exists and is active
        3. Check borrowing limit
        4. Update book availability
        5. Insert borrowing log
        
        Args:
            member_id: Member ID borrowing the book
            isbn: ISBN of the book to borrow
            borrowing_period_days: Number of days for borrowing
            
        Returns:
            log_id of the borrowing transaction
            
        Raises:
            BookNotFoundError: If book doesn't exist
            BookNotAvailableError: If no copies available
            MemberNotFoundError: If member doesn't exist
            BorrowLimitExceededError: If member exceeded limit
            DatabaseError: On transaction failure
        """
        with self.transaction() as conn:
            with conn.cursor() as cur:
                # Step 1: Check if book exists and is available
                cur.execute("SELECT book_id, available_copies FROM Books WHERE isbn = %s FOR UPDATE", (isbn,))
                book_row = cur.fetchone()
                
                if not book_row:
                    raise BookNotFoundError(f"Book with ISBN {isbn} not found")
                
                book_id, available_copies = book_row
                
                if available_copies <= 0:
                    raise BookNotAvailableError(f"Book with ISBN {isbn} is not available")
                
                # Step 2: Check if member exists and is active
                cur.execute("SELECT member_id, status, borrowing_limit FROM Members WHERE member_id = %s FOR UPDATE", (member_id,))
                member_row = cur.fetchone()
                
                if not member_row:
                    raise MemberNotFoundError(f"Member with ID {member_id} not found")
                
                member_id_db, member_status, borrowing_limit = member_row
                
                if member_status != 'Active':
                    raise DatabaseError(f"Member is not active (status: {member_status})")
                
                # Step 3: Check borrowing limit
                cur.execute("""
                    SELECT COUNT(*) as count
                    FROM BorrowingLog
                    WHERE member_id = %s AND status IN ('Borrowed', 'Overdue')
                """, (member_id,))
                current_borrowings = cur.fetchone()[0]
                
                if current_borrowings >= borrowing_limit:
                    raise BorrowLimitExceededError(
                        f"Member has reached borrowing limit of {borrowing_limit}"
                    )
                
                # Step 4: Update book availability
                cur.execute("""
                    UPDATE Books
                    SET available_copies = available_copies - 1,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE book_id = %s
                """, (book_id,))
                
                # Step 5: Insert borrowing log
                due_date = date.today() + timedelta(days=borrowing_period_days)
                
                cur.execute("""
                    INSERT INTO BorrowingLog (member_id, book_id, due_date, status)
                    VALUES (%s, %s, %s, 'Borrowed')
                    RETURNING log_id
                """, (member_id, book_id, due_date))
                
                log_id = cur.fetchone()[0]
                
                logger.info(
                    f"Book borrowed: Member {member_id} borrowed book {isbn} "
                    f"(log_id: {log_id}, due: {due_date})"
                )
                
                return log_id
    
    def return_book(self, log_id: int) -> bool:
        """
        Return a book and update relevant tables.
        
        Args:
            log_id: Borrowing log ID
            
        Returns:
            True if successful
            
        Raises:
            DatabaseError: If return fails
        """
        with self.transaction() as conn:
            with conn.cursor() as cur:
                # Get the borrowing log entry
                cur.execute("""
                    SELECT book_id, member_id, due_date, return_date
                    FROM BorrowingLog
                    WHERE log_id = %s
                """, (log_id,))
                
                log_row = cur.fetchone()
                if not log_row:
                    raise DatabaseError(f"Borrowing log {log_id} not found")
                
                book_id, member_id, due_date, return_date = log_row
                
                if return_date:
                    raise DatabaseError(f"Book has already been returned")
                
                # Update book availability
                cur.execute("""
                    UPDATE Books
                    SET available_copies = available_copies + 1,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE book_id = %s
                """, (book_id,))
                
                # Update borrowing log
                cur.execute("""
                    UPDATE BorrowingLog
                    SET return_date = CURRENT_DATE,
                        status = 'Returned',
                        updated_at = CURRENT_TIMESTAMP
                    WHERE log_id = %s
                """, (log_id,))
                
                logger.info(f"Book returned: log_id {log_id}")
                return True
    
    def calculate_and_record_fine(self, log_id: int, fine_rate_per_day: float = 0.50) -> Optional[int]:
        """
        Calculate and record a fine for an overdue book.
        
        Args:
            log_id: Borrowing log ID
            fine_rate_per_day: Daily fine rate in currency units
            
        Returns:
            fine_id if fine was recorded, None if not overdue
        """
        with self.transaction() as conn:
            with conn.cursor() as cur:
                # Get the borrowing log entry
                cur.execute("""
                    SELECT member_id, due_date, return_date
                    FROM BorrowingLog
                    WHERE log_id = %s
                """, (log_id,))
                
                log_row = cur.fetchone()
                if not log_row:
                    raise DatabaseError(f"Borrowing log {log_id} not found")
                
                member_id, due_date, return_date = log_row
                
                # Check if already fined
                cur.execute("""
                    SELECT fine_id FROM Fines WHERE log_id = %s
                """, (log_id,))
                if cur.fetchone():
                    return None  # Already fined
                
                # Calculate days overdue
                if return_date:
                    calculation_date = return_date
                else:
                    calculation_date = date.today()
                
                days_overdue = (calculation_date - due_date).days
                
                if days_overdue <= 0:
                    return None  # Not overdue
                
                amount = days_overdue * fine_rate_per_day
                
                # Insert fine
                cur.execute("""
                    INSERT INTO Fines (log_id, member_id, amount, fine_rate_per_day,
                                     days_overdue, calculation_date, status)
                    VALUES (%s, %s, %s, %s, %s, %s, 'Unpaid')
                    RETURNING fine_id
                """, (log_id, member_id, amount, fine_rate_per_day, days_overdue, calculation_date))
                
                fine_id = cur.fetchone()[0]
                
                # Update borrowing log status if still borrowed
                cur.execute("""
                    UPDATE BorrowingLog
                    SET status = CASE
                        WHEN return_date IS NULL THEN 'Overdue'
                        ELSE status
                    END
                    WHERE log_id = %s
                """, (log_id,))
                
                logger.info(
                    f"Fine recorded: log_id {log_id}, fine_id {fine_id}, "
                    f"amount: {amount}, days: {days_overdue}"
                )
                
                return fine_id
    
    def pay_fine(self, fine_id: int) -> bool:
        """
        Pay a fine.
        
        Args:
            fine_id: Fine ID to pay
            
        Returns:
            True if successful
        """
        with self.transaction() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    UPDATE Fines
                    SET status = 'Paid',
                        payment_date = CURRENT_TIMESTAMP,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE fine_id = %s
                """, (fine_id,))
                
                if cur.rowcount == 0:
                    raise DatabaseError(f"Fine {fine_id} not found")
                
                logger.info(f"Fine paid: fine_id {fine_id}")
                return True
    
    def get_outstanding_fines(self, member_id: int) -> List[Dict]:
        """
        Get all outstanding fines for a member.
        
        Args:
            member_id: Member ID
            
        Returns:
            List of fine dictionaries
        """
        query = """
            SELECT f.*, b.title, b.isbn, bl.due_date, bl.return_date
            FROM Fines f
            JOIN BorrowingLog bl ON f.log_id = bl.log_id
            JOIN Books b ON bl.book_id = b.book_id
            WHERE f.member_id = %s AND f.status = 'Unpaid'
            ORDER BY f.calculation_date DESC
        """
        return self.execute_query(query, (member_id,), fetch=True) or []
    
    def seed_database(self, books_data: List[Dict]) -> None:
        """
        Seed the database with scraped book data.
        
        Args:
            books_data: List of book dictionaries from scraper
        """
        logger.info(f"Seeding database with {len(books_data)} books")
        
        for book_data in books_data:
            try:
                # Create author objects
                authors = []
                for author_name in book_data.get('authors', []):
                    # Parse author name (assuming "FirstName LastName" format)
                    parts = author_name.split(maxsplit=1)
                    if len(parts) == 2:
                        first_name, last_name = parts
                    else:
                        first_name = ""
                        last_name = parts[0] if parts else "Unknown"
                    
                    authors.append(Author(
                        first_name=first_name,
                        last_name=last_name,
                        nationality=book_data.get('nationality', ''),
                        biography=book_data.get('biography', '')
                    ))
                
                # Create book object
                book = Book(
                    isbn=book_data['isbn'],
                    title=book_data['title'],
                    publication_year=book_data.get('publication_year'),
                    genre=book_data.get('genre', []),
                    synopsis=book_data.get('synopsis', ''),
                    total_copies=1,
                    available_copies=1,
                    language=book_data.get('language', 'English'),
                    publisher=book_data.get('publisher', ''),
                    authors=authors
                )
                
                self.insert_book(book)
                
            except DuplicateISBNError:
                logger.warning(f"Duplicate ISBN skipped: {book_data['isbn']}")
            except Exception as e:
                logger.error(f"Error seeding book {book_data.get('title', 'Unknown')}: {e}")
        
        logger.info("Database seeding completed")
    
    def close(self):
        """Close the connection pool."""
        if hasattr(self, 'pool'):
            self.pool.closeall()
            logger.info("Database connection pool closed")

