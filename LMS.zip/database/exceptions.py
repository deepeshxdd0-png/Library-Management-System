"""Custom exceptions for the Library Management System."""


class LMSException(Exception):
    """Base exception for LMS errors."""
    pass


class DatabaseError(LMSException):
    """Raised when a database operation fails."""
    pass


class BookNotAvailableError(LMSException):
    """Raised when attempting to borrow a book that is not available."""
    pass


class BorrowLimitExceededError(LMSException):
    """Raised when a member has exceeded their borrowing limit."""
    pass


class FineNotPaidError(LMSException):
    """Raised when attempting an operation that requires fines to be paid."""
    pass


class DuplicateISBNError(LMSException):
    """Raised when attempting to add a book with an existing ISBN."""
    pass


class MemberNotFoundError(LMSException):
    """Raised when a member is not found in the database."""
    pass


class BookNotFoundError(LMSException):
    """Raised when a book is not found in the database."""
    pass


class AuthorNotFoundError(LMSException):
    """Raised when an author is not found in the database."""
    pass

